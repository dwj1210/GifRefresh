//
//  ViewController.m
//  GifRefreshDemo
//
//  Created by 代伟佳 on 2017/1/5.
//  Copyright © 2017年 baoLiQiHang. All rights reserved.
//

#import "ViewController.h"
#import "DWJ_GIFRefreshHeader.h"
#import "DWJ_GIFRefreshFooter.h"

#define KWidth ([UIScreen mainScreen].bounds.size.width)
#define KHeight ([UIScreen mainScreen].bounds.size.height - 64)

@interface ViewController () <UITableViewDelegate,UITableViewDataSource>

@property (strong, nonatomic) UITableView *tableView;

@property (strong, nonatomic) NSMutableArray *mutArray;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"gif动画刷新";
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, KWidth, KHeight)  style:UITableViewStylePlain];
    self.tableView.tableFooterView = [UIView new];
    [self.view addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
#pragma mark - MJ顶部刷新
    self.tableView.mj_header = [DWJ_GIFRefreshHeader headerWithRefreshingTarget:self refreshingAction:@selector(shuaxin)];
    
#pragma mark - MJ底部刷新
    self.tableView.mj_footer = [DWJ_GIFRefreshFooter footerWithRefreshingTarget:self refreshingAction:@selector(shuaxin)];
    
    
}

- (void)shuaxin {
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [self.tableView.mj_header endRefreshing];
        [self.tableView.mj_footer endRefreshing];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self.mutArray addObject:@"1"];
            [self.tableView reloadData];
        });
    });
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.mutArray.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    cell.textLabel.text = [NSString stringWithFormat:@"第%ld行",indexPath.row];
    return cell;
}

- (NSMutableArray *)mutArray {
    
    if (!_mutArray) {
        _mutArray = [NSMutableArray arrayWithObjects:@"1",@"1",@"1", nil];
    }
    return _mutArray;
}

@end
