//
//  DWJ_GIFRefreshFooter.m
//  shuaxin
//
//  Created by 代伟佳 on 2017/1/5.
//  Copyright © 2017年 baoLiQiHang. All rights reserved.
//

#import "DWJ_GIFRefreshFooter.h"

@implementation DWJ_GIFRefreshFooter

#pragma mark - 重写父类的方法
- (void)prepare{
    
    [super prepare];
    
    // 创建一个数组来存放普通状态下的gif图片（就是在下拉过程中，还没有达到松手即刷新界限的时刻）
    NSMutableArray *normalImages = [NSMutableArray array];
    for (NSUInteger i = 1; i<= 1; i++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"Refresh－%ld", i]];
        [normalImages addObject:image];
    }
    
    // 创建一个数组来存放将要刷新时需要展示的gif图片数组（就是松手即刷新的时刻）
    NSMutableArray *refreshingImages = [NSMutableArray array];
    for (NSUInteger i = 1; i<=2; i++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"Refresh－%ld", i]];
        [refreshingImages addObject:image];
    }
    
    // 设置上拉过程中的图片数组（这个数组设置与否都不影响刷新）
    [self setImages:normalImages forState:MJRefreshStateIdle];
    // 设置松手即刷新时的图片数组（这个数组设置与否都不影响刷新）
    [self setImages:normalImages forState:MJRefreshStatePulling];
    // 设置正在刷新状态时的动画图片
    [self setImages:refreshingImages forState:MJRefreshStateRefreshing];
    
    // 隐藏正在刷新的文字
    self.refreshingTitleHidden = YES;
}

@end
