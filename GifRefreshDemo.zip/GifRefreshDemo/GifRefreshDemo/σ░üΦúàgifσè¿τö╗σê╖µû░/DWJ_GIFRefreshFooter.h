//
//  DWJ_GIFRefreshFooter.h
//  shuaxin
//
//  Created by 代伟佳 on 2017/1/5.
//  Copyright © 2017年 baoLiQiHang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJRefresh.h"

@interface DWJ_GIFRefreshFooter : MJRefreshAutoGifFooter

@end
